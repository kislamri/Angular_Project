export interface AppointmentObject{
    findLocation: string;
    planVisit: string;
    findDoctor: string;
    insured: string;
}