export interface DoctorObject{
    name: string;
    specialities: string;
    location: string;
    phoneNumber: string;
    visitingHours: string;
}