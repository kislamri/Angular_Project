export interface SicknessObject{
    firstName: string ;
    lastName: string ;
    emailId: string ;
    phoneNumber: number;
    patientType: string ;
    dateOfBirth: string ;
    symptoms1: string ;
    symptoms2: string ;
    symptoms3: string ;
    diseases: string ;

}