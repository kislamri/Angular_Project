export interface PatientObject{
    firstName: string ;
    lastName: string ;
    dob: Date ;
    phone: string;
    patientType: string ;
    gender: string ;
    reasonOfVisit: string ;
  
}